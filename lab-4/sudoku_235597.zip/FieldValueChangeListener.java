

public interface FieldValueChangeListener {
    public void fieldsChanged();
}
